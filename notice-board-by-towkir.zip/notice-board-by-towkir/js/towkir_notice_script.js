jQuery('#clear_notice_url').click( function(e){
	e.preventDefault();
	jQuery('#towkir_notice_url').val("");
});